#Set working directory
setwd("/Users/armourandrew/Desktop/animation")

# Produce animation for all the samples in your dataset -----------------------------------------------------------------------

# Get the number of rows in raw_file
num_rows <- nrow(raw_file)

# Set the path for background image
base_path <- "/Users/armourandrew/Desktop/track/"
file_ext <- ".png"

# Read the background image

for (i in 1:num_rows) {
  # Convert the current row data to a data frame
  df <- convert_row_to_df(raw_file, i)
  
  # Set the path for background image
  background_image <- readPNG(paste0(base_path, raw_file$track[i], file_ext))

                            
  # Create a ggplot object
  p <- ggplot(df, aes(x, y)) +
    # Add the background image and specify the coordinate range
    annotation_raster(background_image, 
                      xmin = 0, xmax = 2160, 
                      ymin = 0, ymax = 2160, 
                      interpolate = TRUE) +
    # Add a trajectory line so that the past trajectory remains visible
    geom_line(color = "blue", size = 1) +
    # Add the current trajectory point
    geom_point(color = "red", size = 5) +
    # Fix the x-axis range
    xlim(0, 2160) +
    # Fix the y-axis range
    ylim(0, 2160) +
    # Animation parameters
    transition_reveal(index)
  
  
  # Extract values from relevant columns for naming
  current_id <- raw_file[i, "ID"]
  current_track <- raw_file[i, "track"]
  current_record <- raw_file[i, "record"]
  
  # Generate the file name using ID, track, and record count with datetime
  file_name <- paste0(current_id, "_", current_track, "_", current_record, ".gif")
  
  # Save the animation
  anim <- animate(
    p, 
    duration = ceiling(raw_file[row_num, "time_spent"]/1000), 
    fps = 60,
    renderer = gifski_renderer(file_name)
  )
}
