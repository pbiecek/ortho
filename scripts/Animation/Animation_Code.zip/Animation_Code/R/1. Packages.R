# Install necessary packages
if (!require(stringr)) install.packages("stringr")
if (!require(ggplot2)) install.packages("ggplot2")
if (!require(gganimate)) install.packages("gganimate")
if (!require(png)) install.packages("png")

# Load the required libraries
library(ggplot2)
library(gganimate)
library(png)


# Define a function to convert a string representing a sequence into an R vector
convert_str_to_vector <- function(str) {
  # Remove square brackets
  str <- gsub("\\[|\\]", "", str)
  # Split the string
  elements <- strsplit(str, ",")[[1]]
  # Try to convert elements to numeric type
  elements <- as.numeric(elements)
  return(elements)
}

# Define the main function to convert the x and y values of a certain row into a data.frame
convert_row_to_df <- function(dataset, row_num) {
  
  # Check if the row number is valid
  if (row_num < 1 || row_num > nrow(dataset)) {
    stop("Invalid row number. Please enter a valid row number.")
  }
  
  # Get the values of columns x and y in the specified row
  x_str <- dataset[row_num, "x"]
  y_str <- dataset[row_num, "y"]
  
  # Convert strings to vectors
  x_vec <- convert_str_to_vector(x_str)
  y_vec <- convert_str_to_vector(y_str)
  
  # Create a data.frame
  result_df <- data.frame(x = x_vec, y = y_vec, index = seq_along(x_vec))
  
  result_df$x <- result_df$x + 240
  result_df$y <- result_df$y + 240
  
  return(result_df)
}

# Define the filtering function
filter_dataframe <- function(data, filters) {
  # Initialize the filtering condition
  condition <- "TRUE"
  
  # Iterate through each filtering condition
  for (i in seq_along(filters)) {
    # Extract the column name, operator, and value
    col_name <- names(filters)[i]
    operator <- filters[[i]][1]
    value <- filters[[i]][2]
    
    # Construct the condition string based on the operator
    if (operator == "==") {
      new_condition <- paste0(col_name, " == '", value, "'")
    } else if (operator == "!=") {
      new_condition <- paste0(col_name, " != '", value, "'")
    } else if (operator == ">") {
      new_condition <- paste0(col_name, " > ", value)
    } else if (operator == "<") {
      new_condition <- paste0(col_name, " < ", value)
    } else if (operator == ">=") {
      new_condition <- paste0(col_name, " >= ", value)
    } else if (operator == "<=") {
      new_condition <- paste0(col_name, " <= ", value)
    }
    
    # Combine the conditions
    condition <- paste(condition, " & ", new_condition)
  }
  
  # Remove extra spaces and symbols
  condition <- gsub("^ & | & $", "", condition)
  
  # Apply the filtering condition
  result <- subset(data, eval(parse(text = condition)))
  
  return(result)
}