# Filter your data

# Load the file
raw_file <- read.csv("/Users/armourandrew/Desktop/filtered_8234.csv")

# Filtering conditions
filters <- list(
  ID = c("==", "20230619-0010")
)

# Call the function to perform the filtering
raw_file <- filter_dataframe(raw_file, filters)
rownames(raw_file) <- NULL
raw_file <- subset(raw_file, select = -X)    